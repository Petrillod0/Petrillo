﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GunInteract : Interactable {


    public string[] dialogue;
    public string npcName;

    //public static bool isHeldByPlayer;

    public float gunRotationAmount;
    
    public override void Interact()
    {
        foreach (Collider2D col in overlapCircle)
        {
            if (col.gameObject.tag == "Player" 
                && SceneLoader.currentScene == "In Front of Barn")
            {
                print("rotate");

                Transform player = col.gameObject.transform;
                Transform playerRightArm = player.Find("PlayerRig").Find("RightArm");
                Vector3 gunPosition = playerRightArm.Find("Gun Position").position;
                transform.position = gunPosition;
                transform.rotation = Quaternion.Euler(0f, 0f, gunRotationAmount);
                transform.SetParent(playerRightArm);

                if (playerRightArm.localEulerAngles.z < 180 && playerRightArm.localEulerAngles.z > 0)
                {
                    transform.Rotate(new Vector3(transform.rotation.x, transform.rotation.y, transform.rotation.z + 180));
                }
                else
                {
                    transform.gameObject.GetComponent<SpriteRenderer>().flipX = true;
                }


            }
        }
        if(SceneLoader.currentScene == "In Front of Barn")
        {
            DialogueSystem.instance.AddNewDialogue(dialogue, npcName);
        }

    }
}
