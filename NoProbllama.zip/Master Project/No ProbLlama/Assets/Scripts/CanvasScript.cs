﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CanvasScript : MonoBehaviour {

    private static CanvasScript Instance = null;
    private bool updatedCanvas;
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }


        else if (Instance != this)
        {
            Destroy(gameObject);
        }


        DontDestroyOnLoad(gameObject);
    }

    private void Update()
    {
        if(SceneManager.GetActiveScene().name == "In Front of Barn" && !updatedCanvas)
        {
            updatedCanvas = true;

        }
    }
}
