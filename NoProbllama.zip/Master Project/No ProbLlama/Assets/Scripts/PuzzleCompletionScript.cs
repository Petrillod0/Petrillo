﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PuzzleCompletionScript : MonoBehaviour
{

	public bool isPuzzleCompleted;

	private List<GameObject> doors;

    private void Start()
    {
        doors = new List<GameObject>();
        AddDoors();
    }
    void Update ()
	{
        //if (SceneLoader.finishedLoadingScene)
        //{
        //    print("setting doors");
        //    AddDoors();
        //    Invoke("AddDoors",.1f);
        //}

		if (isPuzzleCompleted)
        {
            print("current room status " + GameManager.instance.currentRoom.isComplete);
            GameManager.instance.currentRoom.isComplete = true;



			foreach (GameObject door in doors) {
				door.transform.Find("Door Frame").GetComponent<SpriteRenderer>().color = Color.blue;
			}
		}
        if (GameManager.instance.currentRoom != null && GameManager.instance.currentRoom.isComplete)
        {
            isPuzzleCompleted = true;
        }
        else
        {
            isPuzzleCompleted = false;
        }
	}

    public void AddDoors()
    {

        doors.Clear();

        if (GameObject.Find("Level Exits") != null
            && GameObject.Find("Level Exits").transform.Find("Top Door").gameObject.activeInHierarchy)
        {
            doors.Add(GameObject.Find("Top Door"));
        }
        if (GameObject.Find("Level Exits") != null
            && GameObject.Find("Level Exits").transform.Find("Bottom Door").gameObject.activeInHierarchy)
        {
            doors.Add(GameObject.Find("Bottom Door"));
        }
        if (GameObject.Find("Level Exits") != null
            && GameObject.Find("Level Exits").transform.Find("Left Door").gameObject.activeInHierarchy)
        {
            doors.Add(GameObject.Find("Left Door"));
        }
        if (GameObject.Find("Level Exits") != null
            && GameObject.Find("Level Exits").transform.Find("Right Door").gameObject.activeInHierarchy)
        {
            doors.Add(GameObject.Find("Right Door"));
        }
    }
}
