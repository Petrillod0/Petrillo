﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueButton : MonoBehaviour {

	public GateManager gm;

	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.tag == "Object") {

			Destroy (this.gameObject);
			Destroy (other.gameObject);
			gm.OpenBlueGate ();
		}

		if (other.tag == "Player")
		{
			gm.OpenBlueGate ();
			Destroy (this.gameObject);
		}
	}
}
