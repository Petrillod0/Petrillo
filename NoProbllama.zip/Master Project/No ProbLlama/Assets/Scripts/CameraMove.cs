﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour {


    private Vector3 velocity = Vector3.zero;

    public float smoothTime = .1f;

    public Transform target;
    

    private float cameraZPosition = -10f;

    public bool YMaxEnabled, YMinEnabled, XMaxEnabled, XMinEnabled;
    public float YMaxValue, YMinValue, XMaxValue, XMinValue;

    private void LateUpdate()
    {
       
        Vector3 targetPosition = target.position;

        if(YMaxEnabled && YMinEnabled)
        {
            targetPosition.y = Mathf.Clamp(target.position.y, YMinValue, YMaxValue);
        }
        else if (YMaxEnabled)
        {
            targetPosition.y = Mathf.Clamp(target.position.y, target.position.y, YMaxValue);
        }
        else if (YMinEnabled)
        {
            targetPosition.y = Mathf.Clamp(target.position.y, YMinValue, target.position.y);
        }

        if (XMaxEnabled && XMinEnabled)
        {
            targetPosition.x = Mathf.Clamp(target.position.x, XMinValue, XMaxValue);
        }
        else if (XMaxEnabled)
        {
            targetPosition.x = Mathf.Clamp(target.position.x, target.position.x, XMaxValue);
        }
        else if (XMinEnabled)
        {
            targetPosition.x = Mathf.Clamp(target.position.x, XMinValue, target.position.x);
        }
        targetPosition.z = cameraZPosition;

        transform.position = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, smoothTime);
        
        
    }
}
